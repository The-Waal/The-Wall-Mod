return {
	["AllBoss"] = true,
	["Dev"] = false,
	["Base"] = "penunt-butter",
        ["Scaling"] = "jelly",
}