# **The Wall mod!**

This \*awesome\* mod adds a few new features to balatro!
Currently this mod is in beta, so most features wont be fully functional yet.
---

Adds:

* One new hand
* Two blinds (or like 20 blinds I just like removed the ones I didn't like lol)
* Can make all blinds boss blinds
* Can make all blinds 0 blind size

It may not be much now, but soon it will improve!

